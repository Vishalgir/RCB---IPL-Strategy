#11.	In the "Match" table, some entries in the "Opponent_Team" column are incorrectly spelled as "Delhi_Capitals" instead of "Delhi_Daredevils". Write an SQL query to replace all occurrences of "Delhi_Capitals" with "Delhi_Daredevils".

SELECT * FROM Team;

SELECT Team_Id, REPLACE(Team_name, "Delhi Daredevils", "Delhi Capitals") AS Team_name FROM Team;
