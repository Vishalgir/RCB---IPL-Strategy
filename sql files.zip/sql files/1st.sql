#1. List the different dtypes of columns in table “ball_by_ball” (using information schema)
SELECT COLUMN_NAME, DATA_TYPE 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'Ball_by_Ball' 
AND TABLE_SCHEMA = 'ipl';

 

