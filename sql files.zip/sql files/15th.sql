#15.	Are there players whose performance is more suited to specific venues or conditions? (how would you present this using charts?) 
WITH season_wise_avg AS (
    SELECT 
        t5.Season_Year,
        t1.Striker AS Player_Id,
        t2.Player_Name,
        SUM(t1.Runs_Scored) AS Total_Runs,
        COUNT(DISTINCT t1.Match_Id) AS Matches_Played,
        COUNT(DISTINCT CASE WHEN t3.Kind_Out IS NOT NULL THEN t1.Match_Id END) AS Dismissals,
        ROUND(SUM(t1.Runs_Scored) / NULLIF(COUNT(DISTINCT CASE WHEN t3.Kind_Out IS NOT NULL THEN t1.Match_Id END), 0), 2) AS Batting_Average
    FROM ball_by_ball t1
    JOIN player t2 ON t1.Striker = t2.Player_Id
    JOIN matches t4 ON t1.Match_Id = t4.Match_Id
    JOIN season t5 ON t4.Season_Id = t5.Season_Id
    LEFT JOIN wicket_taken t3 
        ON t1.Match_Id = t3.Match_Id 
        AND t1.Over_Id = t3.Over_Id 
        AND t1.Ball_Id = t3.Ball_Id 
        AND t1.Innings_No = t3.Innings_No
    GROUP BY t5.Season_Year, t1.Striker, t2.Player_Name
    HAVING Batting_Average > 30
), 
qualified_players AS (
    SELECT Player_Id
    FROM season_wise_avg
    GROUP BY Player_Id
    HAVING COUNT(DISTINCT Season_Year) >= 4
)
SELECT s.Player_Id, s.Player_Name, s.Season_Year, s.Batting_Average
FROM season_wise_avg s
JOIN qualified_players q ON s.Player_Id = q.Player_Id
ORDER BY s.Player_Id, s.Season_Year;
