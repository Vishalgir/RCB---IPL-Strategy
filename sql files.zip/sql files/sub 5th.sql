#5.	Are there players whose presence positively influences the morale and performance of the team? (justify your answer using visualization)
WITH season_matches AS (
    SELECT m.Match_Id, s.Season_Year
    FROM matches m
    JOIN season s ON m.Season_Id = s.Season_Id
    WHERE s.Season_Year IN (2015, 2016)
),
total_runs AS (
    SELECT b.Striker AS Batsman_Id, SUM(b.Runs_Scored) AS Total_Runs
    FROM ball_by_ball b
    JOIN season_matches sm ON b.Match_Id = sm.Match_Id
    WHERE b.Runs_Scored IS NOT NULL
    GROUP BY b.Striker
),
boundary_runs AS (
    SELECT b.Striker AS Batsman_Id, SUM(b.Runs_Scored) AS Boundary_Runs
    FROM ball_by_ball b
    JOIN season_matches sm ON b.Match_Id = sm.Match_Id
    WHERE b.Runs_Scored IN (4, 6)
    GROUP BY b.Striker
),
final_stats AS (
    SELECT t.Batsman_Id, p.Player_Name, 
           t.Total_Runs, 
           COALESCE(b.Boundary_Runs, 0) AS Boundary_Runs, 
           ROUND((COALESCE(b.Boundary_Runs, 0) * 100.0) / NULLIF(t.Total_Runs, 0), 2) AS Boundary_Percentage
    FROM total_runs t
    LEFT JOIN boundary_runs b ON t.Batsman_Id = b.Batsman_Id
    JOIN player p ON t.Batsman_Id = p.Player_Id
    WHERE t.Total_Runs >= 100
)
SELECT * FROM final_stats
ORDER BY Boundary_Percentage DESC;


