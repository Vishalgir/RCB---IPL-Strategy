#14.Which of the given players have consistently performed well in past seasons? (will you use any visualization to solve the problem)

WITH batting_performance AS (
    SELECT 
        p.Player_Id,
        p.Player_Name,
        s.Season_Year,
        SUM(bb.Runs_Scored) AS Total_Runs,
        COUNT(CASE WHEN wk.Kind_Out IS NOT NULL THEN 1 END) AS Dismissals,
        COUNT(bb.Ball_Id) AS Balls_Faced
    FROM ball_by_ball bb
    JOIN matches m ON bb.Match_Id = m.Match_Id
    JOIN season s ON m.Season_Id = s.Season_Id
    JOIN player p ON bb.Striker = p.Player_Id  
    LEFT JOIN wicket_taken wk ON bb.Match_Id = wk.Match_Id 
                              AND bb.Over_Id = wk.Over_Id 
                              AND bb.Ball_Id = wk.Ball_Id 
                              AND bb.Innings_No = wk.Innings_No 
                              AND bb.Striker = wk.Player_Out  
    GROUP BY p.Player_Id, p.Player_Name, s.Season_Year
),
bowling_performance AS (
    SELECT 
        p.Player_Id,
        p.Player_Name,
        s.Season_Year,
        COUNT(wk.Kind_Out) AS Total_Wickets,
        SUM(bb.Runs_Scored) AS Runs_Conceded,
        COUNT(bb.Ball_Id) / 6.0 AS Overs_Bowled
    FROM ball_by_ball bb
    JOIN matches m ON bb.Match_Id = m.Match_Id
    JOIN season s ON m.Season_Id = s.Season_Id
    JOIN player p ON bb.Bowler = p.Player_Id
    LEFT JOIN wicket_taken wk ON bb.Match_Id = wk.Match_Id 
                              AND bb.Over_Id = wk.Over_Id 
                              AND bb.Ball_Id = wk.Ball_Id 
                              AND bb.Innings_No = wk.Innings_No 
                              AND bb.Bowler = wk.Kind_Out  
    GROUP BY p.Player_Id, p.Player_Name, s.Season_Year
)
SELECT 
    bp.Season_Year, 
    bp.Player_Name, 
    bp.Total_Runs, 
    ROUND(bp.Total_Runs / NULLIF(bp.Dismissals, 0), 2) AS Batting_Avg, 
    ROUND((bp.Total_Runs / NULLIF(bp.Balls_Faced, 0)) * 100, 2) AS Strike_Rate, 
    bp.Dismissals,
    bp.Balls_Faced,
    bp.Player_Id,
    bw.Total_Wickets,
    ROUND(NULLIF(bw.Runs_Conceded, 0) / NULLIF(bw.Total_Wickets, 0), 2) AS Bowling_Avg,
    ROUND(NULLIF(bw.Runs_Conceded, 0) / NULLIF(bw.Overs_Bowled, 0), 2) AS Economy_Rate
FROM batting_performance bp
LEFT JOIN bowling_performance bw ON bp.Player_Id = bw.Player_Id AND bp.Season_Year = bw.Season_Year
ORDER BY bp.Season_Year, bp.Total_Runs DESC;
