#9.	Come up with a visual and analytical analysis of the RCB's past season's performance and potential reasons for them not winning a trophy.
SELECT 
    S.Season_Id,
    SUM(CASE WHEN M.Match_Winner = T.Team_Id THEN 1 ELSE 0 END) AS Wins,
    SUM(CASE WHEN M.Match_Winner != T.Team_Id THEN 1 ELSE 0 END) AS Losses
FROM 
    Matches M
JOIN 
    Player_Match PM ON M.Match_Id = PM.Match_Id
JOIN 
    Team T ON PM.Team_Id = T.Team_Id
JOIN 
    Season S ON M.Season_Id = S.Season_Id
WHERE 
    T.Team_Name = 'Royal Challengers Bangalore'
GROUP BY 
    S.Season_Id;
    
    SELECT 
    V.Venue_Name,
    SUM(CASE WHEN M.Match_Winner = T.Team_Id THEN 1 ELSE 0 END) AS Wins,
    COUNT(DISTINCT M.Match_Id) AS TotalMatches
FROM 
    Matches M
JOIN 
    Venue V ON M.Venue_Id = V.Venue_Id
JOIN 
    Player_Match PM ON M.Match_Id = PM.Match_Id
JOIN 
    Team T ON PM.Team_Id = T.Team_Id
WHERE 
    T.Team_Name = 'Royal Challengers Bangalore'
GROUP BY 
    V.Venue_Name;
    


SELECT 
    SUM(B.Runs_Scored) AS DeathOverRuns,
    COUNT(W.Ball_Id) AS DeathOverWickets  
FROM 
    Ball_by_Ball B
LEFT JOIN 
    Wicket_Taken W ON B.Match_Id = W.Match_Id AND B.Ball_Id = W.Ball_Id  
JOIN 
    Player_Match PM ON B.Match_Id = PM.Match_Id
JOIN 
    Team T ON PM.Team_Id = T.Team_Id
WHERE 
    B.Over_Id BETWEEN 16 AND 20
    AND T.Team_Name = 'Royal Challengers Bangalore';


