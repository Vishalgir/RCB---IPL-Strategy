#3.	How many players were more than the age of 25 during season 2014?

SELECT 
    COUNT(*) AS Player_Count
FROM 
    (SELECT 
        Player_Id, 
        Player_Name, 
        DOB, 
        TIMESTAMPDIFF(YEAR, DOB, '2014-06-30') AS Age_In_2014
     FROM 
        Player
     WHERE 
        TIMESTAMPDIFF(YEAR, DOB, '2014-06-30') > 25) AS Older_Players; 