#2.	Suggest some of the players who would be best fit for the team.
WITH batting_stats AS (
    SELECT 
        b.Striker AS Player_Id, 
        p.Player_Name,
        COUNT(b.Ball_Id) AS Balls_Faced,
        SUM(b.Runs_Scored) AS Total_Runs,
        ROUND(SUM(b.Runs_Scored) / NULLIF(COUNT(b.Ball_Id), 0), 2) AS Batting_Avg,
        ROUND((SUM(b.Runs_Scored) * 100.0) / NULLIF(COUNT(b.Ball_Id), 0), 2) AS Strike_Rate
    FROM ball_by_ball b
    JOIN player p ON b.Striker = p.Player_Id
    GROUP BY Player_Id, p.Player_Name
)
SELECT * FROM batting_stats 
ORDER BY Batting_Avg DESC, Strike_Rate DESC
LIMIT 4;




WITH allrounder_stats AS (
    SELECT 
        b.Striker AS Player_Id, 
        p.Player_Name,
        SUM(b.Runs_Scored) AS Total_Runs,
        COUNT(b.Ball_Id) AS Balls_Faced,
        ROUND(SUM(b.Runs_Scored) / NULLIF(COUNT(b.Ball_Id), 0), 2) AS Batting_Avg,
        ROUND((SUM(b.Runs_Scored) * 100.0) / NULLIF(COUNT(b.Ball_Id), 0), 2) AS Strike_Rate,
        COUNT(CASE WHEN w.Kind_Out IS NOT NULL THEN 1 END) AS Total_Wickets,
        SUM(b.Runs_Scored) AS Runs_Conceded,
        COUNT(b.Ball_Id) / 6.0 AS Overs_Bowled,
        ROUND(SUM(b.Runs_Scored) / NULLIF(COUNT(b.Ball_Id) / 6.0, 0), 2) AS Economy_Rate
    FROM ball_by_ball b
    LEFT JOIN wicket_taken w 
        ON b.Match_Id = w.Match_Id 
        AND b.Over_Id = w.Over_Id 
        AND b.Ball_Id = w.Ball_Id
    JOIN player p ON b.Striker = p.Player_Id
    GROUP BY Player_Id, p.Player_Name
)
SELECT * FROM allrounder_stats 
WHERE Total_Wickets > 10 AND Total_Runs > 200  -- Ensuring they contribute in both
ORDER BY Total_Wickets DESC, Total_Runs DESC
LIMIT 3;


WITH bowling_stats AS (
    SELECT 
        b.Bowler AS Player_Id, 
        p.Player_Name,
        COUNT(CASE WHEN w.Kind_Out IS NOT NULL THEN 1 END) AS Total_Wickets,
        SUM(b.Runs_Scored) AS Runs_Conceded,
        COUNT(b.Ball_Id) / 6.0 AS Overs_Bowled,
        ROUND(SUM(b.Runs_Scored) / NULLIF(COUNT(b.Ball_Id) / 6.0, 0), 2) AS Economy_Rate
    FROM ball_by_ball b
    LEFT JOIN wicket_taken w 
        ON b.Match_Id = w.Match_Id 
        AND b.Over_Id = w.Over_Id 
        AND b.Ball_Id = w.Ball_Id
    JOIN player p ON b.Bowler = p.Player_Id
    GROUP BY Player_Id, p.Player_Name
)
SELECT * FROM bowling_stats 
ORDER BY Total_Wickets DESC, Economy_Rate ASC
LIMIT 4;

