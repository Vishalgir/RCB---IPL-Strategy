#1.	How does the toss decision affect the result of the match? (which visualizations could be used to present your answer better) And is the impact limited to only specific venues?
WITH toss_analysis AS (
    SELECT 
        m.Venue_Id,
        v.Venue_Name,
        m.Toss_Winner,
        m.Match_Winner,
        CASE 
            WHEN m.Toss_Winner = m.Match_Winner THEN 'Won'
            ELSE 'Lost'
        END AS Toss_Outcome,
        m.Toss_Decide  -- Corrected column name
    FROM matches m
    JOIN venue v ON m.Venue_Id = v.Venue_Id
),
win_percentage AS (
    SELECT 
        Venue_Id,
        Venue_Name,
        Toss_Decide AS Toss_Decision,  -- Renaming for readability
        COUNT(*) AS Total_Matches,
        SUM(CASE WHEN Toss_Outcome = 'Won' THEN 1 ELSE 0 END) AS Wins,
        ROUND((SUM(CASE WHEN Toss_Outcome = 'Won' THEN 1 ELSE 0 END) * 100.0) / COUNT(*), 2) AS Win_Percentage
    FROM toss_analysis
    GROUP BY Venue_Id, Venue_Name, Toss_Decide
)
SELECT * FROM win_percentage
ORDER BY Venue_Id, Win_Percentage DESC;

