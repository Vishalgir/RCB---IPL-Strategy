#3.	What are some of the parameters that should be focused on while selecting the players?
SELECT 
    p.Player_Name, 
    SUM(b.Runs_Scored) AS Total_Runs,
    COUNT(w.Match_Id) AS Total_Dismissals,
    ROUND(SUM(b.Runs_Scored) / NULLIF(COUNT(w.Match_Id), 0), 2) AS Average_Performance
FROM ball_by_ball b
JOIN player p ON b.Striker = p.Player_Id
LEFT JOIN wicket_taken w 
    ON b.Match_Id = w.Match_Id 
    AND b.Over_Id = w.Over_Id 
    AND b.Ball_Id = w.Ball_Id 
    AND b.Innings_No = w.Innings_No
    AND b.Striker = w.Player_Out
GROUP BY p.Player_Name
ORDER BY Average_Performance DESC;





