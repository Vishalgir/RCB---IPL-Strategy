#8.	Analyze the impact of home-ground advantage on team performance and identify strategies to maximize this advantage for RCB.
WITH RCB_Team AS (
    SELECT Team_Id
    FROM Team
    WHERE Team_Name = 'Royal Challengers Bangalore'
),
HomeMatches AS (
    SELECT 
        M.Match_Id,
        M.Match_Winner
    FROM 
        Matches M
    JOIN 
        Venue V ON M.Venue_Id = V.Venue_Id
    JOIN 
        Player_Match PM ON M.Match_Id = PM.Match_Id
    JOIN 
        RCB_Team RCB ON PM.Team_Id = RCB.Team_Id
    WHERE 
        V.Venue_Name = 'M Chinnaswamy Stadium'
    GROUP BY 
        M.Match_Id, M.Match_Winner
),
HomeWins AS (
    SELECT 
        COUNT(*) AS TotalHomeWins
    FROM 
        HomeMatches
    JOIN 
        RCB_Team RCB ON HomeMatches.Match_Winner = RCB.Team_Id
),
TotalHomeMatches AS (
    SELECT 
        COUNT(*) AS TotalHomeMatches
    FROM 
        HomeMatches
)
SELECT 
    IFNULL((HomeWins.TotalHomeWins * 100.0 / TotalHomeMatches.TotalHomeMatches), 0) AS HomeWinPercentage
FROM 
    HomeWins, TotalHomeMatches;