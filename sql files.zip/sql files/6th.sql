#6.	What are the average runs scored by each batsman considering all the seasons?
WITH player_total_runs AS (
    SELECT  
        bb.Striker AS Player_Id,  
        SUM(bb.Runs_Scored) AS Total_Runs,  
        COUNT(DISTINCT m.Match_Id) AS Matches_Played  
    FROM Ball_by_Ball bb  
    JOIN Matches m ON bb.Match_Id = m.Match_Id  
    WHERE bb.Runs_Scored IS NOT NULL  
    GROUP BY bb.Striker  
)  
SELECT  
    p.Player_Name,  
    pr.Total_Runs,  
    pr.Matches_Played,  
    (pr.Total_Runs * 1.0 / NULLIF(pr.Matches_Played, 0)) AS Avg_Runs_Per_Match  
FROM player_total_runs pr  
JOIN Player p ON pr.Player_Id = p.Player_Id  
ORDER BY Avg_Runs_Per_Match DESC;

