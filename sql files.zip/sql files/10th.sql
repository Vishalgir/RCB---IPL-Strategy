#10.	What is the impact of bowling style on wickets taken?
WITH cte AS (
    SELECT 
        bb.Bowler AS Player_Id, 
        p.Player_Name, 
        bs.Bowling_Skill, 
        COUNT(ot.Out_Id) AS Total_Wickets 
    FROM 
        Ball_by_Ball bb
    LEFT JOIN 
        Out_Type ot ON bb.Ball_Id = ot.Out_Id 
    JOIN 
        Player p ON bb.Bowler = p.Player_Id 
    JOIN 
        Bowling_style bs ON p.Bowling_skill = bs.Bowling_Id 
    WHERE 
        ot.Out_Id IS NOT NULL 
    GROUP BY 
        bb.Bowler, p.Player_Name, bs.Bowling_Skill
)
SELECT 
    Bowling_Skill, 
    SUM(Total_Wickets) AS Total_Wickets_Taken
FROM 
    cte
GROUP BY 
    Bowling_Skill
ORDER BY 
    Total_Wickets_Taken DESC;