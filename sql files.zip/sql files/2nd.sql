#2.	What is the total number of runs scored in 1st season by RCB (bonus: also include the extra runs using the extra runs table)
SELECT 
    SUM(CASE WHEN e.Extra_Type_Id IS NULL THEN e.Extra_Runs ELSE 0 END) AS Runs_Scored,
    SUM(CASE WHEN e.Extra_Type_Id IS NOT NULL THEN e.Extra_Runs ELSE 0 END) AS Extra_Runs_Conceded,
    SUM(e.Extra_Runs) AS Total_Runs_Scored
FROM 
    Extra_Runs e
JOIN 
    Ball_by_Ball b ON e.Ball_Id = b.Ball_Id AND e.Innings_No = b.Innings_No AND e.Match_Id = b.Match_Id
JOIN 
    Matches m ON b.Match_Id = m.Match_Id
WHERE 
    m.Season_Id = 1 
    AND b.Team_Batting = 'RCB'; 