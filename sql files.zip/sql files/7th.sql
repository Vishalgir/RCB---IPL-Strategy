#7.	What are the average wickets taken by each bowler considering all the seasons?
WITH bowler_wickets AS (
    SELECT  
        bb.Bowler AS Player_Id,  
        COUNT(*) AS Total_Wickets,  
        COUNT(DISTINCT m.Match_Id) AS Matches_Played  
    FROM Ball_by_Ball bb  
    JOIN Matches m ON bb.Match_Id = m.Match_Id  
    WHERE bb.Runs_Scored = 0    
      AND bb.Striker IS NOT NULL    
    GROUP BY bb.Bowler  
)  
SELECT  
    p.Player_Name,  
    bw.Total_Wickets,  
    bw.Matches_Played,  
    (bw.Total_Wickets * 1.0 / NULLIF(bw.Matches_Played, 0)) AS Avg_Wickets_Per_Match  
FROM bowler_wickets bw  
JOIN Player p ON bw.Player_Id = p.Player_Id  
ORDER BY Avg_Wickets_Per_Match DESC;
