#12.	Can you derive more KPIs for the team strategy?
WITH Last_Two_Seasons AS (
    SELECT Season_Id, Season_Year, 
           DENSE_RANK() OVER(ORDER BY Season_Year DESC) AS rnk
    FROM Season
),
Filtered_Seasons AS (
    SELECT Season_Id FROM Last_Two_Seasons WHERE rnk <= 2
),
Ball_Data AS (
    SELECT 
        t1.Match_Id, t1.Over_Id, t1.Ball_Id, t1.Innings_No, 
        t1.Striker AS Batsman_Id, t1.Runs_Scored, t3.Season_Id
    FROM Ball_by_Ball t1  
    JOIN Matches t3 
        ON t1.Match_Id = t3.Match_Id
    WHERE t3.Season_Id IN (SELECT Season_Id FROM Filtered_Seasons)
),
Batsman_Stats AS (
    SELECT 
        Batsman_Id, 
        SUM(Runs_Scored) AS Total_Runs, 
        COUNT(*) AS Total_Balls
    FROM Ball_Data
    GROUP BY Batsman_Id
    HAVING COUNT(*) >= 200
)
SELECT 
    bs.Batsman_Id AS Player_Id, 
    p.Player_Name, 
    bs.Total_Runs, 
    bs.Total_Balls, 
    ROUND((bs.Total_Runs * 100.0) / bs.Total_Balls, 2) AS Strike_Rate
FROM Batsman_Stats bs
LEFT JOIN Player p 
    ON bs.Batsman_Id = p.Player_Id
ORDER BY Strike_Rate DESC
LIMIT 20;




