#5.	List the top 10 players according to their strike rate in the last 4 seasons

WITH last_4_seasons AS (
    SELECT DISTINCT Season_Id  
    FROM Season  
    ORDER BY Season_Id DESC  
    LIMIT 4
), player_stats AS (
    SELECT  
        bb.Striker AS Player_Id,  
        SUM(bb.Runs_Scored) AS Total_Runs,  
        COUNT(*) AS Balls_Faced  
    FROM Ball_by_Ball bb  
    JOIN Matches m ON bb.Match_Id = m.Match_Id  
    WHERE m.Season_Id IN (SELECT Season_Id FROM last_4_seasons)  
      AND bb.Runs_Scored IS NOT NULL 
    GROUP BY bb.Striker  
)  
SELECT  
    p.Player_Name,  
    ps.Total_Runs,  
    ps.Balls_Faced,  
    (ps.Total_Runs * 100.0 / NULLIF(ps.Balls_Faced, 0)) AS Strike_Rate  
FROM player_stats ps  
JOIN Player p ON ps.Player_Id = p.Player_Id  
ORDER BY Strike_Rate DESC  
LIMIT 10;