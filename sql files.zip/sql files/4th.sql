#4.	How many matches did RCB win in 2013? 

    SELECT 
    COUNT(*) AS RCB_Wins_In_2013
FROM 
    Matches
WHERE 
    Match_Winner = 'RCB' 
    AND Season_Id = 2013; 
    