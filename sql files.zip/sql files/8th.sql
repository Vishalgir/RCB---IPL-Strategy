#8.	List all the players who have average runs scored greater than the overall 
#average and who have taken wickets greater than the overall average
WITH player_runs AS (
    SELECT  
        bb.Striker AS Player_Id,  
        SUM(bb.Runs_Scored) AS Total_Runs,  
        COUNT(DISTINCT m.Match_Id) AS Matches_Played,  
        (SUM(bb.Runs_Scored) * 1.0 / NULLIF(COUNT(DISTINCT m.Match_Id), 0)) AS Avg_Runs_Per_Match  
    FROM Ball_by_Ball bb  
    JOIN Matches m ON bb.Match_Id = m.Match_Id  
    GROUP BY bb.Striker  
), overall_avg_runs AS (
    SELECT AVG(Avg_Runs_Per_Match) AS Overall_Avg_Runs  
    FROM player_runs  
), bowler_wickets AS (
    SELECT  
        bb.Bowler AS Player_Id,  
        COUNT(*) AS Total_Wickets,  
        COUNT(DISTINCT m.Match_Id) AS Matches_Played,  
        (COUNT(*) * 1.0 / NULLIF(COUNT(DISTINCT m.Match_Id), 0)) AS Avg_Wickets_Per_Match  
    FROM Ball_by_Ball bb  
    JOIN Matches m ON bb.Match_Id = m.Match_Id  
    WHERE bb.Runs_Scored = 0  
      AND bb.Striker IS NOT NULL  
    GROUP BY bb.Bowler  
), overall_avg_wickets AS (
    SELECT AVG(Avg_Wickets_Per_Match) AS Overall_Avg_Wickets  
    FROM bowler_wickets  
)  
SELECT  
    p.Player_Name,  
    pr.Avg_Runs_Per_Match,  
    bw.Avg_Wickets_Per_Match  
FROM player_runs pr  
JOIN bowler_wickets bw ON pr.Player_Id = bw.Player_Id  
JOIN Player p ON pr.Player_Id = p.Player_Id  
WHERE  
    pr.Avg_Runs_Per_Match > (SELECT Overall_Avg_Runs FROM overall_avg_runs)  
    AND bw.Avg_Wickets_Per_Match > (SELECT Overall_Avg_Wickets FROM overall_avg_wickets)  
ORDER BY pr.Avg_Runs_Per_Match DESC, bw.Avg_Wickets_Per_Match DESC;
