#4.	Which players offer versatility in their skills and can contribute effectively with both bat and ball? (can you visualize the data for the same)
WITH Batting AS (
    SELECT b.Striker AS Player_Id, p.Player_Name, 
           SUM(b.Runs_Scored) AS Total_Runs, 
           COUNT(DISTINCT b.Match_Id) AS Innings_Played,
           ROUND(SUM(b.Runs_Scored) / NULLIF(COUNT(DISTINCT b.Match_Id), 0), 2) AS Batting_Avg
    FROM ball_by_ball b
    JOIN player p ON b.Striker = p.Player_Id
    GROUP BY b.Striker, p.Player_Name
),
Overall_Batting_Avg AS (
    -- Calculate overall batting average
    SELECT ROUND(AVG(Batting_Avg), 2) AS Overall_Batting_Avg FROM Batting
),
Bowling AS (
    SELECT b.Bowler AS Player_Id, p.Player_Name, 
           COUNT(w.Kind_Out) AS Total_Wickets
    FROM ball_by_ball b
    JOIN wicket_taken w 
        ON b.Match_Id = w.Match_Id 
        AND b.Over_Id = w.Over_Id 
        AND b.Ball_Id = w.Ball_Id
    JOIN player p ON b.Bowler = p.Player_Id
    WHERE w.Kind_Out IS NOT NULL
    GROUP BY b.Bowler, p.Player_Name
),
Overall_Wickets_Avg AS (
    -- Calculate overall average wickets taken
    SELECT ROUND(AVG(Total_Wickets), 2) AS Overall_Wickets_Avg FROM Bowling
)
SELECT b.Player_Id, b.Player_Name, b.Batting_Avg, bw.Total_Wickets
FROM Batting b
JOIN Bowling bw ON b.Player_Id = bw.Player_Id
JOIN Overall_Batting_Avg oba ON b.Batting_Avg > oba.Overall_Batting_Avg
JOIN Overall_Wickets_Avg owa ON bw.Total_Wickets > owa.Overall_Wickets_Avg
ORDER BY b.Batting_Avg DESC, bw.Total_Wickets DESC;





