#13.	Using SQL, write a query to find out the average wickets taken by each bowler in each venue. Also, rank the gender according to the average value.
WITH wickets_cte AS (
    SELECT 
        m.Venue_Id, 
        v.Venue_Name, 
        b.Bowler AS Player_Id, 
        COUNT(w.Kind_Out) AS Total_Wickets 
    FROM ball_by_ball b
    JOIN wicket_taken w 
        ON b.Match_Id = w.Match_Id 
        AND b.Over_Id = w.Over_Id 
        AND b.Ball_Id = w.Ball_Id 
        AND b.Innings_No = w.Innings_No
    JOIN out_type ot 
        ON w.Kind_Out = ot.Out_Id
    JOIN matches m 
        ON b.Match_Id = m.Match_Id
    JOIN venue v 
        ON m.Venue_Id = v.Venue_Id
    WHERE ot.Out_Name NOT IN ('run out', 'retired hurt', 'obstructing the field')
    GROUP BY m.Venue_Id, v.Venue_Name, b.Bowler
),
runs_conceded_cte AS (
    SELECT 
        m.Venue_Id, 
        v.Venue_Name, 
        b.Bowler AS Player_Id, 
        SUM(b.Runs_Scored) AS Total_Runs_Conceded 
    FROM ball_by_ball b
    JOIN matches m 
        ON b.Match_Id = m.Match_Id
    JOIN venue v 
        ON m.Venue_Id = v.Venue_Id
    GROUP BY m.Venue_Id, v.Venue_Name, b.Bowler
)
SELECT 
    r.Venue_Id, 
    r.Venue_Name, 
    r.Player_Id, 
    p.Player_Name, 
    r.Total_Runs_Conceded, 
    w.Total_Wickets, 
    ROUND(NULLIF(r.Total_Runs_Conceded, 0) / NULLIF(w.Total_Wickets, 0), 2) AS Bowling_Average,
    DENSE_RANK() OVER (PARTITION BY r.Venue_Id ORDER BY (NULLIF(r.Total_Runs_Conceded, 0) / NULLIF(w.Total_Wickets, 0))) AS Ranking
FROM runs_conceded_cte r
JOIN wickets_cte w 
    ON r.Venue_Id = w.Venue_Id 
    AND r.Player_Id = w.Player_Id
JOIN player p 
    ON r.Player_Id = p.Player_Id
ORDER BY r.Venue_Id, Ranking;





