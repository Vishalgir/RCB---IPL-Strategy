#11.	Write the SQL query to provide a status of whether the performance of the team is better than the previous year's performance on the basis of the number of runs scored by the team in the season and the number of wickets taken 
WITH team_performance AS (
    SELECT 
        m.Season_ID,
        s.Season_Year,
        b.Team_Batting AS Team_ID,  
        t.Team_Name,
        SUM(b.Runs_Scored) AS Total_Score,
        COUNT(w.Player_Out) AS Total_Wickets
    FROM matches m
    JOIN season s ON m.Season_ID = s.Season_ID
    JOIN ball_by_ball b ON m.Match_ID = b.Match_ID
    JOIN team t ON b.Team_Batting = t.Team_ID 
    LEFT JOIN wicket_taken w ON b.Match_ID = w.Match_ID 
        AND b.Over_ID = w.Over_ID 
        AND b.Ball_ID = w.Ball_ID
    GROUP BY m.Season_ID, s.Season_Year, b.Team_Batting, t.Team_Name
),
performance_trend AS (
    SELECT 
        Season_ID,
        Season_Year,
        Team_ID,
        Team_Name,
        Total_Score,
        LAG(Total_Score, 1, 0) OVER (PARTITION BY Team_ID ORDER BY Season_Year) AS Prev_Total_Score,
        Total_Wickets,
        LAG(Total_Wickets, 1, 0) OVER (PARTITION BY Team_ID ORDER BY Season_Year) AS Prev_Total_Wickets,
        MIN(Season_Year) OVER (PARTITION BY Team_ID) AS First_Season_Year
    FROM team_performance
)
SELECT 
    Season_Year,
    Team_Name,
    Total_Score,
    Prev_Total_Score,
    Total_Wickets,
    Prev_Total_Wickets,
    CASE 
        WHEN Season_Year = First_Season_Year THEN 'First Season'
        WHEN Total_Score > Prev_Total_Score AND Total_Wickets > Prev_Total_Wickets THEN 'Better'
        ELSE 'Decline'
    END AS Performance_Status
FROM performance_trend
ORDER BY Team_Name, Season_Year;