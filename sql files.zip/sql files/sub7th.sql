#7.	What do you think could be the factors contributing to the high-scoring matches and the impact on viewership and team strategies
SELECT 
    CASE 
        WHEN Over_Id BETWEEN 1 AND 6 THEN 'Powerplay (1-6)'
        WHEN Over_Id BETWEEN 7 AND 16 THEN 'Middle Overs (7-16)'
        WHEN Over_Id BETWEEN 17 AND 20 THEN 'Death Overs (17-20)'
    END AS Over_Phase,
    SUM(COALESCE(Runs_Scored, 0)) AS Total_Runs,
    COUNT(DISTINCT Match_Id) AS Matches_Played,
    ROUND(AVG(COALESCE(Runs_Scored, 0)), 2) AS Avg_Runs_Per_Match
FROM Ball_by_Ball
GROUP BY Over_Phase
ORDER BY FIELD(Over_Phase, 'Powerplay (1-6)', 'Middle Overs (7-16)', 'Death Overs (17-20)');


SELECT 
    CASE 
        WHEN Over_Id BETWEEN 1 AND 6 THEN 'Powerplay (1-6)'
        WHEN Over_Id BETWEEN 7 AND 16 THEN 'Middle Overs (7-16)'
        WHEN Over_Id BETWEEN 17 AND 20 THEN 'Death Overs (17-20)'
    END AS Over_Phase,
    COUNT(Player_Out) AS Total_Wickets
FROM wicket_taken
GROUP BY Over_Phase
ORDER BY FIELD(Over_Phase, 'Powerplay (1-6)', 'Middle Overs (7-16)', 'Death Overs (17-20)');



